"""
Typhoon Track Visualization and Prediction System - Streamlit Web Application
Interactive web interface for ANN-based typhoon trajectory prediction
"""

import streamlit as st
import numpy as np
import pandas as pd
import os
import sys
import time

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.data_preprocessing import TyphoonDataProcessor
from src.ann_model import ArtificialNeuralNetwork
from src.visualization import TyphoonVisualizer
from config import IBTRACS_CSV, ANN_MODELS_DIR, VISUALIZATIONS_DIR, PREDICTIONS_DIR
import matplotlib.pyplot as plt
from streamlit_folium import folium_static


# Page configuration
st.set_page_config(
    page_title="Typhoon Track Prediction System",
    page_icon="🌀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        padding: 1rem 0;
        border-bottom: 3px solid #1f77b4;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 0.5rem;
        padding: 1rem;
        margin: 1rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 0.5rem;
        padding: 1rem;
        margin: 1rem 0;
    }
    </style>
""", unsafe_allow_html=True)


# Initialize session state
if 'processor' not in st.session_state:
    st.session_state.processor = None
if 'model' not in st.session_state:
    st.session_state.model = None
if 'window_size' not in st.session_state:
    st.session_state.window_size = 5
if 'trained' not in st.session_state:
    st.session_state.trained = False
if 'storms_df' not in st.session_state:
    st.session_state.storms_df = None


def initialize_processor():
    """Initialize the data processor"""
    csv_file = 'ibtracs.WP.list.v04r01.csv'
    
    if not os.path.exists(csv_file):
        st.error(f"❌ Data file '{csv_file}' not found!")
        st.info("Please ensure the IBTrACS dataset is in the project directory.")
        return None
    
    if st.session_state.processor is None:
        with st.spinner("Loading typhoon track data..."):
            processor = TyphoonDataProcessor(csv_file)
            processor.load_data()
            st.session_state.processor = processor
    
    return st.session_state.processor


def load_storms():
    """Load and cache storm list"""
    if st.session_state.storms_df is None:
        processor = initialize_processor()
        if processor:
            storms = processor.get_storm_list()
            storms = storms[storms['NUM_POINTS'] >= 20]  # Filter minimum points
            st.session_state.storms_df = storms
    
    return st.session_state.storms_df


def training_page():
    """Training mode page"""
    st.markdown("<div class='main-header'>🎓 Train ANN Model</div>", unsafe_allow_html=True)
    
    processor = initialize_processor()
    if not processor:
        return
    
    storms_df = load_storms()
    if storms_df is None or len(storms_df) == 0:
        st.error("No storms available for training")
        return
    
    # Training Configuration
    st.subheader("⚙️ Training Configuration")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        num_storms = st.number_input(
            "Number of Storms",
            min_value=1,
            max_value=min(100, len(storms_df)),
            value=10,
            help="Number of storms to use for training the model"
        )
    
    with col2:
        window_size = st.number_input(
            "Window Size",
            min_value=3,
            max_value=10,
            value=5,
            help="Number of previous positions to use as input"
        )
    
    with col3:
        epochs = st.number_input(
            "Training Epochs",
            min_value=100,
            max_value=5000,
            value=1000,
            step=100,
            help="Number of training iterations"
        )
    
    # Advanced settings
    with st.expander("🔧 Advanced Settings"):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            learning_rate = st.number_input(
                "Learning Rate",
                min_value=0.0001,
                max_value=0.1,
                value=0.001,
                format="%.4f"
            )
        
        with col2:
            batch_size = st.number_input(
                "Batch Size",
                min_value=8,
                max_value=128,
                value=32
            )
        
        with col3:
            hidden_layer_1 = st.number_input(
                "Hidden Layer 1 Size",
                min_value=16,
                max_value=256,
                value=64
            )
            hidden_layer_2 = st.number_input(
                "Hidden Layer 2 Size",
                min_value=8,
                max_value=128,
                value=32
            )
    
    # Display selected storms
    st.subheader("📊 Training Storms")
    selected_storms = storms_df.head(num_storms)
    st.dataframe(
        selected_storms[['SID', 'NAME', 'SEASON', 'NUM_POINTS']],
        use_container_width=True,
        height=300
    )
    
    # Training button
    if st.button("🚀 Start Training", type="primary", use_container_width=True):
        try:
            # Prepare training data
            training_storm_ids = selected_storms['SID'].tolist()
            
            progress_bar = st.progress(0, text="Preparing training data...")
            X_train, y_train = processor.prepare_training_data(training_storm_ids, window_size)
            progress_bar.progress(20, text="Training data prepared!")
            
            st.info(f"📈 Training data shape: X={X_train.shape}, y={y_train.shape}")
            
            # Create model
            input_size = window_size * 2
            model = ArtificialNeuralNetwork(
                input_size=input_size,
                hidden_sizes=[hidden_layer_1, hidden_layer_2],
                output_size=2,
                learning_rate=learning_rate
            )
            
            progress_bar.progress(30, text="Model initialized, starting training...")
            
            # Training with progress updates
            st.write("### 📊 Training Progress")
            
            # Create placeholder for live updates
            status_placeholder = st.empty()
            chart_placeholder = st.empty()
            
            # Train model
            model.train(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=False)
            
            progress_bar.progress(90, text="Training completed! Saving model...")
            
            # Save model
            model_path = 'typhoon_ann_model.pkl'
            model.save_model(model_path)
            
            # Update session state
            st.session_state.model = model
            st.session_state.window_size = window_size
            st.session_state.trained = True
            
            progress_bar.progress(100, text="✅ Training completed successfully!")
            
            # Display training results
            st.markdown("<div class='success-box'>", unsafe_allow_html=True)
            st.success("✅ Model training completed successfully!")
            st.markdown("</div>", unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Final Loss", f"{model.loss_history[-1]:.6f}")
            with col2:
                st.metric("Training Epochs", epochs)
            with col3:
                st.metric("Training Samples", len(X_train))
            
            # Plot training history
            st.subheader("📈 Training Loss History")
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.plot(model.loss_history, linewidth=2, color='#1f77b4')
            ax.set_xlabel('Epoch', fontsize=12)
            ax.set_ylabel('Loss (MSE)', fontsize=12)
            ax.set_title('Training Loss Over Time', fontsize=14, fontweight='bold')
            ax.grid(True, alpha=0.3)
            st.pyplot(fig)
            
            # Save training history plot
            visualizer = TyphoonVisualizer()
            visualizer.plot_training_history(model.loss_history)
            
        except Exception as e:
            st.error(f"❌ Training failed: {str(e)}")


def prediction_page():
    """Prediction mode page"""
    st.markdown("<div class='main-header'>🔮 Predict Typhoon Track</div>", unsafe_allow_html=True)
    
    # Check if model is loaded
    if st.session_state.model is None:
        model_path = 'typhoon_ann_model.pkl'
        if os.path.exists(model_path):
            with st.spinner("Loading trained model..."):
                st.session_state.model = ArtificialNeuralNetwork.load_model(model_path)
                st.session_state.window_size = st.session_state.model.input_size // 2
                st.session_state.trained = True
            st.success("✅ Model loaded successfully!")
        else:
            st.warning("⚠️ No trained model found. Please train a model first.")
            return
    
    processor = initialize_processor()
    if not processor:
        return
    
    storms_df = load_storms()
    if storms_df is None or len(storms_df) == 0:
        st.error("No storms available")
        return
    
    # Storm selection
    st.subheader("🌀 Select Typhoon Storm")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Create display format for storms
        storm_options = [
            f"{row['SID']} - {row['NAME']} ({row['SEASON']}) - {row['NUM_POINTS']} points"
            for idx, row in storms_df.iterrows()
        ]
        
        selected_idx = st.selectbox(
            "Select Storm",
            range(len(storm_options)),
            format_func=lambda x: storm_options[x]
        )
    
    with col2:
        use_positions = st.number_input(
            "Positions to Display",
            min_value=st.session_state.window_size + 1,
            max_value=100,
            value=st.session_state.window_size + 5,
            help="Number of historical positions to show"
        )
    
    # Get selected storm
    storm_row = storms_df.iloc[selected_idx]
    storm_id = storm_row['SID']
    storm_name = storm_row['NAME']
    
    # Display storm info
    st.markdown("<div class='metric-card'>", unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Storm ID", storm_id)
    with col2:
        st.metric("Name", storm_name)
    with col3:
        st.metric("Year", storm_row['SEASON'])
    with col4:
        st.metric("Total Points", storm_row['NUM_POINTS'])
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Prediction button
    if st.button("🎯 Make Prediction", type="primary", use_container_width=True):
        try:
            with st.spinner("Analyzing typhoon track..."):
                # Get storm track
                storm_track = processor.get_storm_track(storm_id)
                
                # Prepare data
                if use_positions >= len(storm_track):
                    use_positions = len(storm_track)
                    actual_next = None
                    storm_track_display = storm_track.copy()
                else:
                    actual_next = [storm_track.iloc[use_positions]['LAT'], 
                                  storm_track.iloc[use_positions]['LON']]
                    storm_track_display = storm_track.iloc[:use_positions].copy()
                
                # Prepare input
                recent_positions = [[lat, lon] for lat, lon in 
                                   zip(storm_track_display['LAT'].tail(st.session_state.window_size).values,
                                       storm_track_display['LON'].tail(st.session_state.window_size).values)]
                
                X_input = processor.prepare_prediction_input(recent_positions, st.session_state.window_size)
                
                # Make prediction
                prediction_norm = st.session_state.model.predict(X_input)
                prediction = processor.denormalize_prediction(prediction_norm[0])
            
            # Display results
            st.subheader("📍 Prediction Results")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("### 🔴 Predicted Position")
                st.metric("Latitude", f"{prediction[0]:.4f}°")
                st.metric("Longitude", f"{prediction[1]:.4f}°")
            
            if actual_next is not None:
                with col2:
                    st.markdown("### 🟢 Actual Position")
                    st.metric("Latitude", f"{actual_next[0]:.4f}°")
                    st.metric("Longitude", f"{actual_next[1]:.4f}°")
                
                # Calculate error
                visualizer = TyphoonVisualizer()
                error_km = visualizer.calculate_distance(prediction, actual_next)
                
                st.markdown("<div class='success-box'>", unsafe_allow_html=True)
                st.markdown(f"### 📏 Prediction Error: **{error_km:.2f} km**")
                st.markdown("</div>", unsafe_allow_html=True)
            
            # Generate map
            st.subheader("🗺️ Interactive Track Visualization")
            
            with st.spinner("Generating interactive map..."):
                visualizer = TyphoonVisualizer()
                map_obj = visualizer.create_map(
                    storm_track_display,
                    predicted_position=prediction,
                    actual_next_position=actual_next,
                    storm_name=f"{storm_name} ({storm_id})",
                    window_positions=recent_positions
                )
                
                # Display map
                folium_static(map_obj, width=1200, height=600)
                
                # Save map
                map_filename = f'typhoon_{storm_id}_prediction.html'
                visualizer.save_map(map_filename)
                st.info(f"💾 Map saved as: {map_filename}")
            
        except Exception as e:
            st.error(f"❌ Prediction failed: {str(e)}")


def about_page():
    """About page with system information"""
    st.markdown("<div class='main-header'>ℹ️ About the System</div>", unsafe_allow_html=True)
    
    st.markdown("""
    ## 🌀 Typhoon Track Visualization and Prediction System
    
    ### Overview
    This system uses **Artificial Neural Networks (ANN)** to predict typhoon trajectories based on historical track data 
    from the IBTrACS (International Best Track Archive for Climate Stewardship) dataset.
    
    ### 🧠 How It Works
    
    1. **Data Preprocessing**: Historical typhoon positions (latitude, longitude) are extracted and normalized
    2. **Sliding Window**: Uses previous T time steps as input features to capture movement patterns
    3. **ANN Training**: Feedforward neural network learns spatial patterns through backpropagation
    4. **Prediction**: Trained model forecasts the next position based on recent trajectory
    5. **Visualization**: Interactive maps display historical tracks and predictions with error metrics
    
    ### 🏗️ System Architecture
    
    - **Input Layer**: Historical lat-lon pairs (window_size × 2 features)
    - **Hidden Layers**: Two layers with ReLU activation (default: 64, 32 neurons)
    - **Output Layer**: 2 neurons (predicted latitude and longitude)
    - **Loss Function**: Mean Squared Error (MSE)
    - **Optimizer**: Mini-batch Gradient Descent
    
    ### 📊 Key Features
    
    ✅ Load and preprocess IBTrACS historical data  
    ✅ Customizable ANN architecture and training parameters  
    ✅ Real-time training progress visualization  
    ✅ Interactive map-based predictions  
    ✅ Quantitative error metrics in kilometers  
    ✅ Model persistence (save/load functionality)  
    
    ### 🎯 Use Cases
    
    - **Research**: Study typhoon movement patterns and predictability
    - **Education**: Learn about neural networks applied to geospatial data
    - **Analysis**: Compare predictions with actual trajectories
    
    ### ⚠️ Limitations
    
    - Predictions based solely on historical position data
    - Does not incorporate meteorological variables (pressure, wind, etc.)
    - Accuracy depends on training data quality and quantity
    - Not suitable for operational forecasting
    
    ### 📚 Data Source
    
    **IBTrACS Dataset** - Western Pacific Basin  
    Coverage: Historical typhoon tracks from 1884 to present  
    Source: [NOAA IBTrACS](https://www.ncdc.noaa.gov/ibtracs/)
    
    ### 👨‍💻 Technical Stack
    
    - **Backend**: Python, NumPy, Pandas
    - **ML**: Custom ANN implementation with backpropagation
    - **Visualization**: Folium, Matplotlib
    - **Web Interface**: Streamlit
    
    ---
    
    **Note**: This system is for educational and research purposes. Always consult official meteorological 
    agencies for operational typhoon forecasts.
    """)


def main():
    """Main application"""
    
    # Sidebar
    st.sidebar.image("https://cdn-icons-png.flaticon.com/512/1146/1146869.png", width=100)
    st.sidebar.title("🌀 Typhoon ANN System")
    
    # Navigation
    page = st.sidebar.radio(
        "Navigation",
        ["🔮 Prediction", "🎓 Training", "ℹ️ About"],
        label_visibility="collapsed"
    )
    
    # Model status in sidebar
    st.sidebar.markdown("---")
    st.sidebar.subheader("📊 System Status")
    
    if st.session_state.trained or os.path.exists('typhoon_ann_model.pkl'):
        st.sidebar.success("✅ Model Ready")
        if st.session_state.window_size:
            st.sidebar.info(f"Window Size: {st.session_state.window_size}")
    else:
        st.sidebar.warning("⚠️ No Model Loaded")
    
    # Data status
    if st.session_state.processor is not None:
        st.sidebar.success("✅ Data Loaded")
        if st.session_state.storms_df is not None:
            st.sidebar.info(f"Storms: {len(st.session_state.storms_df)}")
    else:
        st.sidebar.info("📥 Data Not Loaded")
    
    st.sidebar.markdown("---")
    
    # Quick actions
    st.sidebar.subheader("⚡ Quick Actions")
    if st.sidebar.button("🔄 Reload Data", use_container_width=True):
        st.session_state.processor = None
        st.session_state.storms_df = None
        st.rerun()
    
    if st.sidebar.button("🗑️ Clear Model", use_container_width=True):
        st.session_state.model = None
        st.session_state.trained = False
        st.rerun()
    
    # Page routing
    if page == "🎓 Training":
        training_page()
    elif page == "🔮 Prediction":
        prediction_page()
    else:
        about_page()
    
    # Footer
    st.sidebar.markdown("---")
    st.sidebar.caption("🎓 ANN Final Project - Typhoon Track Prediction")
    st.sidebar.caption("© 2026 - Educational Use")


if __name__ == "__main__":
    main()
