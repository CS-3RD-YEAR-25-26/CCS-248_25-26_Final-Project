"""
Typhoon Track Visualization and Prediction System
Main application script integrating ANN-based prediction with geospatial visualization
"""

import numpy as np
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.data_preprocessing import TyphoonDataProcessor
from src.ann_model import ArtificialNeuralNetwork
from src.visualization import TyphoonVisualizer
from config import IBTRACS_CSV, ANN_MODELS_DIR


def display_storm_list(storms_df, max_display=20):
    """Display available storms to choose from"""
    print("\n" + "=" * 80)
    print("AVAILABLE TYPHOON STORMS")
    print("=" * 80)
    print(f"{'Index':<8} {'Storm ID':<20} {'Name':<20} {'Year':<8} {'Points':<8}")
    print("-" * 80)
    
    for idx, row in storms_df.head(max_display).iterrows():
        print(f"{idx:<8} {row['SID']:<20} {row['NAME']:<20} {row['SEASON']:<8} {row['NUM_POINTS']:<8}")
    
    print("-" * 80)
    print(f"Showing {min(max_display, len(storms_df))} of {len(storms_df)} storms")
    print("=" * 80 + "\n")


def train_model_mode(processor):
    """Training mode: Train ANN on multiple storms"""
    print("\n" + "=" * 80)
    print("TRAINING MODE")
    print("=" * 80)
    
    # Get storm list
    storms = processor.get_storm_list()
    
    # Filter storms with sufficient data points
    min_points = 20
    storms = storms[storms['NUM_POINTS'] >= min_points]
    display_storm_list(storms, max_display=30)
    
    # Get training parameters
    print("\nTraining Configuration:")
    
    try:
        num_storms = int(input(f"Number of storms to use for training (max {len(storms)}): "))
        num_storms = min(num_storms, len(storms))
    except:
        num_storms = min(10, len(storms))
        print(f"Using default: {num_storms} storms")
    
    try:
        window_size = int(input("Window size (number of previous positions to use, default 5): "))
    except:
        window_size = 5
        print(f"Using default window size: {window_size}")
    
    try:
        epochs = int(input("Number of training epochs (default 1000): "))
    except:
        epochs = 1000
        print(f"Using default epochs: {epochs}")
    
    # Select storms
    training_storm_ids = storms['SID'].head(num_storms).tolist()
    
    print(f"\nPreparing training data from {len(training_storm_ids)} storms...")
    X_train, y_train = processor.prepare_training_data(training_storm_ids, window_size)
    
    print(f"Training data shape: X={X_train.shape}, y={y_train.shape}")
    
    # Create and train model
    input_size = window_size * 2  # lat, lon pairs
    model = ArtificialNeuralNetwork(
        input_size=input_size,
        hidden_sizes=[64, 32],
        output_size=2,
        learning_rate=0.001
    )
    
    model.train(X_train, y_train, epochs=epochs, batch_size=32, verbose=True)
    
    # Save model
    model_path = os.path.join(ANN_MODELS_DIR, 'typhoon_ann_model.pkl')
    model.save_model(model_path)
    
    # Plot training history
    visualizer = TyphoonVisualizer()
    visualizer.plot_training_history(model.loss_history)
    
    print("\nTraining completed successfully!")
    
    return model, window_size


def prediction_mode(processor, model=None, window_size=5):
    """Prediction mode: Use trained model to predict next position"""
    print("\n" + "=" * 80)
    print("PREDICTION MODE")
    print("=" * 80)
    
    # Load model if not provided
    if model is None:
        model_path = os.path.join(ANN_MODELS_DIR, 'typhoon_ann_model.pkl')
        if not os.path.exists(model_path):
            print(f"Error: Model file '{model_path}' not found!")
            print("Please train a model first using option 1.")
            return
        
        model = ArtificialNeuralNetwork.load_model(model_path)
        # Extract window size from model input size
        window_size = model.input_size // 2
    
    # Get storm list
    storms = processor.get_storm_list()
    
    # Filter storms with sufficient data points
    min_points = window_size + 5
    storms = storms[storms['NUM_POINTS'] >= min_points]
    display_storm_list(storms, max_display=30)
    
    # Select storm
    try:
        storm_idx = int(input("Enter the index of the storm to predict: "))
        storm_id = storms.iloc[storm_idx]['SID']
        storm_name = storms.iloc[storm_idx]['NAME']
    except:
        print("Invalid selection. Using first available storm.")
        storm_id = storms.iloc[0]['SID']
        storm_name = storms.iloc[0]['NAME']
    
    # Get storm track
    storm_track = processor.get_storm_track(storm_id)
    
    print(f"\nSelected Storm: {storm_name} ({storm_id})")
    print(f"Total positions: {len(storm_track)}")
    
    # Ask how many positions to use for prediction
    try:
        use_positions = int(input(f"How many positions to use for visualization (min {window_size + 1}): "))
        use_positions = max(window_size + 1, use_positions)
    except:
        use_positions = min(window_size + 5, len(storm_track))
        print(f"Using default: {use_positions} positions")
    
    # Split data: use first (use_positions - 1) for prediction, last one for validation
    if use_positions >= len(storm_track):
        use_positions = len(storm_track)
        actual_next = None
        storm_track_display = storm_track.copy()
    else:
        actual_next = [storm_track.iloc[use_positions]['LAT'], 
                      storm_track.iloc[use_positions]['LON']]
        storm_track_display = storm_track.iloc[:use_positions].copy()
    
    # Prepare input for prediction (last window_size positions)
    recent_positions = [[lat, lon] for lat, lon in 
                       zip(storm_track_display['LAT'].tail(window_size).values,
                           storm_track_display['LON'].tail(window_size).values)]
    
    X_input = processor.prepare_prediction_input(recent_positions, window_size)
    
    # Make prediction
    print("\nMaking prediction...")
    prediction_norm = model.predict(X_input)
    prediction = processor.denormalize_prediction(prediction_norm[0])
    
    print(f"\nPredicted Next Position:")
    print(f"  Latitude:  {prediction[0]:.4f}")
    print(f"  Longitude: {prediction[1]:.4f}")
    
    # Calculate error if actual position is available
    if actual_next is not None:
        visualizer = TyphoonVisualizer()
        error_km = visualizer.calculate_distance(prediction, actual_next)
        
        print(f"\nActual Next Position:")
        print(f"  Latitude:  {actual_next[0]:.4f}")
        print(f"  Longitude: {actual_next[1]:.4f}")
        print(f"\nPrediction Error: {error_km:.2f} km")
    
    # Visualize
    print("\nGenerating visualization...")
    visualizer = TyphoonVisualizer()
    visualizer.create_map(
        storm_track_display,
        predicted_position=prediction,
        actual_next_position=actual_next,
        storm_name=f"{storm_name} ({storm_id})",
        window_positions=recent_positions
    )
    
    visualizer.display_map(f'typhoon_{storm_id}_prediction.html')
    
    print("\nPrediction completed successfully!")


def main():
    """Main application entry point"""
    print("\n" + "=" * 80)
    print("TYPHOON TRACK VISUALIZATION AND PREDICTION SYSTEM")
    print("Using Artificial Neural Networks (ANN)")
    print("=" * 80)
    
    # Initialize data processor
    csv_file = IBTRACS_CSV
    
    if not os.path.exists(csv_file):
        print(f"\nError: Data file '{csv_file}' not found!")
        print("Please ensure the IBTrACS dataset is in the data/ directory.")
        return
    
    processor = TyphoonDataProcessor(csv_file)
    
    # Main menu
    while True:
        print("\n" + "=" * 80)
        print("MAIN MENU")
        print("=" * 80)
        print("1. Train New Model")
        print("2. Make Prediction (using existing model)")
        print("3. Train and Predict")
        print("4. Exit")
        print("=" * 80)
        
        try:
            choice = input("\nEnter your choice (1-4): ").strip()
        except:
            choice = '4'
        
        if choice == '1':
            train_model_mode(processor)
        
        elif choice == '2':
            prediction_mode(processor)
        
        elif choice == '3':
            print("\nTraining and prediction workflow...")
            model, window_size = train_model_mode(processor)
            
            input("\nPress Enter to continue to prediction...")
            prediction_mode(processor, model, window_size)
        
        elif choice == '4':
            print("\nThank you for using the Typhoon Track Prediction System!")
            print("Goodbye!\n")
            break
        
        else:
            print("\nInvalid choice. Please try again.")


if __name__ == "__main__":
    main()
