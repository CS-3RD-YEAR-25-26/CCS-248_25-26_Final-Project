"""
Enhanced Data Preprocessing for LSTM Model
Includes improved sequence generation and optional meteorological features
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from data_preprocessing import TyphoonDataProcessor


class EnhancedTyphoonDataProcessor(TyphoonDataProcessor):
    """
    Enhanced data processor with support for:
    - Larger window sizes
    - Additional meteorological features
    - Proper train/validation/test splits
    - LSTM-compatible data shapes
    """
    
    def __init__(self, csv_file_path):
        super().__init__(csv_file_path)
        self.feature_scalers = {}
        self.feature_columns = ['LAT', 'LON']  # Base features
    
    def create_lstm_sequences(self, storm_track, window_size=10, include_features=None):
        """
        Create sequences for LSTM training with proper shape
        
        Args:
            storm_track: DataFrame with storm track data
            window_size: Number of previous time steps
            include_features: List of additional feature columns to include
        
        Returns:
            X: (samples, window_size, num_features)
            y: (samples, 2) for lat, lon
        """
        # Determine features to use
        features_to_use = ['LAT', 'LON'].copy()
        if include_features:
            for feature in include_features:
                if feature in storm_track.columns:
                    features_to_use.append(feature)
        
        # Extract feature values
        feature_data = []
        for feature in features_to_use:
            if feature in storm_track.columns:
                values = pd.to_numeric(storm_track[feature], errors='coerce')
                feature_data.append(values.values)
            else:
                print(f"Warning: Feature '{feature}' not found in data")
        
        if not feature_data:
            return None, None
        
        feature_array = np.column_stack(feature_data)
        
        # Remove rows with NaN
        valid_indices = ~np.isnan(feature_array).any(axis=1)
        feature_array = feature_array[valid_indices]
        
        if len(feature_array) <= window_size:
            return None, None
        
        # Create sequences
        X = []
        y = []
        
        for i in range(len(feature_array) - window_size):
            # Input: window_size time steps of all features
            X.append(feature_array[i:i + window_size])
            
            # Output: next position (lat, lon only)
            y.append(feature_array[i + window_size, :2])  # First two are LAT, LON
        
        return np.array(X), np.array(y)
    
    def normalize_lstm_data(self, X, y, fit=True):
        """
        Normalize data for LSTM training
        
        Args:
            X: Input sequences (samples, window_size, num_features)
            y: Output values (samples, 2)
            fit: Whether to fit scalers
        
        Returns:
            X_normalized, y_normalized
        """
        num_features = X.shape[2]
        X_norm = X.copy()
        y_norm = y.copy()
        
        # Initialize scalers if fitting
        if fit:
            for i in range(num_features):
                self.feature_scalers[i] = MinMaxScaler()
        
        # Normalize each feature across all time steps
        for i in range(num_features):
            # Reshape to 2D for scaling
            feature_data = X[:, :, i].reshape(-1, 1)
            
            if fit:
                self.feature_scalers[i].fit(feature_data)
            
            # Scale and reshape back
            scaled_data = self.feature_scalers[i].transform(feature_data)
            X_norm[:, :, i] = scaled_data.reshape(X[:, :, i].shape)
        
        # Normalize output (lat, lon)
        if fit:
            self.scaler_lat.fit(y[:, 0].reshape(-1, 1))
            self.scaler_lon.fit(y[:, 1].reshape(-1, 1))
        
        y_norm[:, 0] = self.scaler_lat.transform(y[:, 0].reshape(-1, 1)).flatten()
        y_norm[:, 1] = self.scaler_lon.transform(y[:, 1].reshape(-1, 1)).flatten()
        
        return X_norm, y_norm
    
    def prepare_lstm_training_data(self, storm_ids, window_size=10, val_split=0.15, 
                                   test_split=0.15, include_features=None):
        """
        Prepare data with proper train/validation/test split
        
        Args:
            storm_ids: List of storm IDs to use
            window_size: Window size for sequences
            val_split: Fraction for validation
            test_split: Fraction for test
            include_features: Additional features to include
        
        Returns:
            (X_train, y_train), (X_val, y_val), (X_test, y_test)
        """
        all_X = []
        all_y = []
        
        print(f"Preparing LSTM training data from {len(storm_ids)} storms...")
        
        for storm_id in storm_ids:
            storm_track = self.get_storm_track(storm_id)
            X, y = self.create_lstm_sequences(storm_track, window_size, include_features)
            
            if X is not None and len(X) > 0:
                all_X.append(X)
                all_y.append(y)
        
        if not all_X:
            raise ValueError("No valid sequences created")
        
        X_combined = np.vstack(all_X)
        y_combined = np.vstack(all_y)
        
        print(f"Total sequences created: {len(X_combined)}")
        print(f"Sequence shape: {X_combined.shape}")
        
        # Calculate split indices
        n_samples = len(X_combined)
        test_size = int(n_samples * test_split)
        val_size = int(n_samples * val_split)
        train_size = n_samples - test_size - val_size
        
        # Split data
        X_train = X_combined[:train_size]
        y_train = y_combined[:train_size]
        
        X_val = X_combined[train_size:train_size + val_size]
        y_val = y_combined[train_size:train_size + val_size]
        
        X_test = X_combined[train_size + val_size:]
        y_test = y_combined[train_size + val_size:]
        
        # Normalize
        X_train_norm, y_train_norm = self.normalize_lstm_data(X_train, y_train, fit=True)
        X_val_norm, y_val_norm = self.normalize_lstm_data(X_val, y_val, fit=False)
        X_test_norm, y_test_norm = self.normalize_lstm_data(X_test, y_test, fit=False)
        
        print(f"\nData split:")
        print(f"  Training: {len(X_train_norm)} samples ({train_size/n_samples*100:.1f}%)")
        print(f"  Validation: {len(X_val_norm)} samples ({val_size/n_samples*100:.1f}%)")
        print(f"  Test: {len(X_test_norm)} samples ({test_size/n_samples*100:.1f}%)")
        
        return (X_train_norm, y_train_norm), (X_val_norm, y_val_norm), (X_test_norm, y_test_norm)
    
    def prepare_lstm_prediction_input(self, recent_positions, window_size=10):
        """
        Prepare input for LSTM prediction
        
        Args:
            recent_positions: List of recent [lat, lon] positions
            window_size: Window size
        
        Returns:
            Normalized input array (1, window_size, num_features)
        """
        if len(recent_positions) < window_size:
            raise ValueError(f"Need at least {window_size} recent positions")
        
        # Take last window_size positions
        positions = np.array(recent_positions[-window_size:])
        
        # Reshape to (1, window_size, num_features)
        X = positions.reshape(1, window_size, -1)
        
        # Normalize
        X_norm = X.copy()
        num_features = X.shape[2]
        
        for i in range(num_features):
            if i in self.feature_scalers:
                feature_data = X[:, :, i].reshape(-1, 1)
                scaled_data = self.feature_scalers[i].transform(feature_data)
                X_norm[:, :, i] = scaled_data.reshape(X[:, :, i].shape)
        
        return X_norm
