"""
Training Script for LSTM Model
Comprehensive training with proper data handling and model evaluation
"""

import numpy as np
import pandas as pd
import os
import sys
import pickle
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_preprocessing_lstm import EnhancedTyphoonDataProcessor
from src.lstm_model import LSTMTyphoonModel
from config import IBTRACS_CSV, LSTM_MODELS_DIR


def main():
    print("=" * 70)
    print(" LSTM Typhoon Track Prediction - Training Script")
    print("=" * 70)
    
    # Configuration
    CSV_PATH = IBTRACS_CSV
    WINDOW_SIZE = 10  # Increased from 5
    LSTM_UNITS = [128, 64]  # Two LSTM layers
    DROPOUT_RATE = 0.3
    LEARNING_RATE = 0.001
    EPOCHS = 150
    BATCH_SIZE = 32
    
    # Model save path
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_save_path = os.path.join(LSTM_MODELS_DIR, f'lstm_model_{timestamp}')
    
    # Step 1: Load and prepare data
    print("\n[1/4] Loading data...")
    processor = EnhancedTyphoonDataProcessor(CSV_PATH)
    
    # Get all storm IDs
    all_storms = processor.get_all_storm_ids()
    print(f"Total storms in dataset: {len(all_storms)}")
    
    # Use more storms for training (at least 100 recommended)
    num_training_storms = min(150, len(all_storms))
    training_storms = all_storms[:num_training_storms]
    
    print(f"Using {num_training_storms} storms for training")
    
    # Step 2: Prepare training data
    print("\n[2/4] Preparing LSTM training data...")
    try:
        (X_train, y_train), (X_val, y_val), (X_test, y_test) = processor.prepare_lstm_training_data(
            storm_ids=training_storms,
            window_size=WINDOW_SIZE,
            val_split=0.15,
            test_split=0.15,
            include_features=None  # Can add ['WMO_WIND', 'WMO_PRES'] if available
        )
    except Exception as e:
        print(f"Error preparing data: {e}")
        return
    
    # Step 3: Build and train model
    print("\n[3/4] Building LSTM model...")
    model = LSTMTyphoonModel(
        window_size=WINDOW_SIZE,
        num_features=X_train.shape[2],
        lstm_units=LSTM_UNITS,
        dropout_rate=DROPOUT_RATE,
        learning_rate=LEARNING_RATE
    )
    
    model.summary()
    
    print(f"\n[4/4] Training model for {EPOCHS} epochs...")
    history = model.train(
        X_train, y_train,
        X_val, y_val,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        verbose=1
    )
    
    # Step 4: Evaluate on test set
    print("\n" + "=" * 70)
    print(" Model Evaluation on Test Set")
    print("=" * 70)
    
    test_results = model.evaluate(X_test, y_test)
    
    # Make sample predictions to check
    print("\nSample predictions vs actual:")
    sample_indices = np.random.choice(len(X_test), min(5, len(X_test)), replace=False)
    predictions = model.predict(X_test[sample_indices])
    
    for i, idx in enumerate(sample_indices):
        pred = predictions[i]
        actual = y_test[idx]
        print(f"  Sample {i+1}: Pred={pred}, Actual={actual}")
    
    # Step 5: Save model
    print("\n" + "=" * 70)
    print(" Saving Model")
    print("=" * 70)
    
    model.save_model(model_save_path)
    
    # Save processor configuration
    with open(f"{model_save_path}_processor.pkl", 'wb') as f:
        pickle.dump(processor, f)
    
    print(f"✅ Model and processor saved with prefix: {model_save_path}")
    
    # Plot training history
    try:
        model.plot_training_history(f"{model_save_path}_history.png")
    except Exception as e:
        print(f"Could not plot training history: {e}")
    
    # Save training summary
    summary = {
        'timestamp': timestamp,
        'num_storms': num_training_storms,
        'window_size': WINDOW_SIZE,
        'lstm_units': LSTM_UNITS,
        'dropout_rate': DROPOUT_RATE,
        'learning_rate': LEARNING_RATE,
        'epochs': EPOCHS,
        'batch_size': BATCH_SIZE,
        'train_samples': len(X_train),
        'val_samples': len(X_val),
        'test_samples': len(X_test),
        'test_loss': test_results[0],
        'test_mae': test_results[1],
        'model_path': model_save_path
    }
    
    with open(f"{model_save_path}_summary.pkl", 'wb') as f:
        pickle.dump(summary, f)
    
    print("\n" + "=" * 70)
    print(" Training Complete!")
    print("=" * 70)
    print(f"\nModel files:")
    print(f"  • {model_save_path}.keras")
    print(f"  • {model_save_path}_config.pkl")
    print(f"  • {model_save_path}_history.pkl")
    print(f"  • {model_save_path}_processor.pkl")
    print(f"  • {model_save_path}_summary.pkl")
    print(f"\nTest Results:")
    print(f"  • MSE Loss: {test_results[0]:.6f}")
    print(f"  • MAE: {test_results[1]:.6f}")
    
    return model, processor, summary


if __name__ == "__main__":
    main()
