"""
LSTM Model for Typhoon Track Prediction
Improved architecture using Long Short-Term Memory networks for temporal sequence modeling
"""

import numpy as np
import pickle
import os

try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers, models, optimizers, callbacks
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False
    print("Warning: TensorFlow not available. Please install: pip install tensorflow")


class LSTMTyphoonModel:
    """
    LSTM-based model for typhoon trajectory prediction
    Designed to capture temporal dependencies in storm movement
    """
    
    def __init__(self, window_size=10, num_features=2, lstm_units=[128, 64], 
                 dropout_rate=0.2, learning_rate=0.001):
        """
        Initialize the LSTM model
        
        Args:
            window_size: Number of previous time steps to use
            num_features: Number of features per time step (2 for lat/lon, more with additional data)
            lstm_units: List of LSTM layer sizes
            dropout_rate: Dropout rate for regularization
            learning_rate: Learning rate for Adam optimizer
        """
        if not TENSORFLOW_AVAILABLE:
            raise ImportError("TensorFlow is required for LSTM model. Install with: pip install tensorflow")
        
        self.window_size = window_size
        self.num_features = num_features
        self.lstm_units = lstm_units
        self.dropout_rate = dropout_rate
        self.learning_rate = learning_rate
        
        self.model = None
        self.history = None
        
        self._build_model()
    
    def _build_model(self):
        """Build the LSTM architecture"""
        self.model = models.Sequential()
        
        # First LSTM layer (return sequences for stacking)
        self.model.add(layers.LSTM(
            self.lstm_units[0],
            return_sequences=True if len(self.lstm_units) > 1 else False,
            input_shape=(self.window_size, self.num_features)
        ))
        self.model.add(layers.Dropout(self.dropout_rate))
        
        # Additional LSTM layers
        for i, units in enumerate(self.lstm_units[1:]):
            return_seq = i < len(self.lstm_units) - 2
            self.model.add(layers.LSTM(units, return_sequences=return_seq))
            self.model.add(layers.Dropout(self.dropout_rate))
        
        # Dense output layer (predict next lat, lon)
        self.model.add(layers.Dense(2))  # 2 outputs: latitude and longitude
        
        # Compile model
        self.model.compile(
            optimizer=optimizers.Adam(learning_rate=self.learning_rate),
            loss='mse',
            metrics=['mae']
        )
        
        print(f"✅ LSTM Model built successfully")
        print(f"   Architecture: Input({self.window_size}, {self.num_features}) -> " + 
              f"LSTM{self.lstm_units} -> Dense(2)")
    
    def summary(self):
        """Print model summary"""
        if self.model:
            self.model.summary()
    
    def train(self, X_train, y_train, X_val=None, y_val=None, epochs=100, batch_size=32, verbose=1):
        """
        Train the LSTM model
        
        Args:
            X_train: Training input (samples, window_size, num_features)
            y_train: Training output (samples, 2)
            X_val: Validation input
            y_val: Validation output
            epochs: Number of training epochs
            batch_size: Batch size
            verbose: Verbosity level
        
        Returns:
            Training history
        """
        # Reshape if needed
        if len(X_train.shape) == 2:
            # Reshape from (samples, window_size*features) to (samples, window_size, features)
            X_train = X_train.reshape(-1, self.window_size, self.num_features)
        
        if X_val is not None and len(X_val.shape) == 2:
            X_val = X_val.reshape(-1, self.window_size, self.num_features)
        
        # Callbacks
        callback_list = [
            callbacks.EarlyStopping(
                monitor='val_loss' if X_val is not None else 'loss',
                patience=20,
                restore_best_weights=True,
                verbose=1
            ),
            callbacks.ReduceLROnPlateau(
                monitor='val_loss' if X_val is not None else 'loss',
                factor=0.5,
                patience=10,
                min_lr=1e-6,
                verbose=1
            )
        ]
        
        # Train model
        print(f"\nTraining LSTM model for {epochs} epochs...")
        print(f"Training data shape: X={X_train.shape}, y={y_train.shape}")
        if X_val is not None:
            print(f"Validation data shape: X={X_val.shape}, y={y_val.shape}")
        
        validation_data = (X_val, y_val) if X_val is not None else None
        
        self.history = self.model.fit(
            X_train, y_train,
            validation_data=validation_data,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callback_list,
            verbose=verbose
        )
        
        print("\n✅ Training completed!")
        return self.history
    
    def predict(self, X):
        """
        Make predictions
        
        Args:
            X: Input data (samples, window_size, num_features) or (samples, window_size*num_features)
        
        Returns:
            Predictions (samples, 2)
        """
        # Reshape if needed
        if len(X.shape) == 2:
            X = X.reshape(-1, self.window_size, self.num_features)
        
        return self.model.predict(X, verbose=0)
    
    def evaluate(self, X_test, y_test):
        """
        Evaluate model on test data
        
        Args:
            X_test: Test input
            y_test: Test output
        
        Returns:
            Test loss and metrics
        """
        if len(X_test.shape) == 2:
            X_test = X_test.reshape(-1, self.window_size, self.num_features)
        
        results = self.model.evaluate(X_test, y_test, verbose=0)
        
        print(f"\nTest Results:")
        print(f"  Loss (MSE): {results[0]:.6f}")
        print(f"  MAE: {results[1]:.6f}")
        
        return results
    
    def save_model(self, filepath='lstm_typhoon_model'):
        """
        Save the model
        
        Args:
            filepath: Path to save (without extension)
        """
        # Save Keras model
        self.model.save(f"{filepath}.keras")
        
        # Save configuration
        config = {
            'window_size': self.window_size,
            'num_features': self.num_features,
            'lstm_units': self.lstm_units,
            'dropout_rate': self.dropout_rate,
            'learning_rate': self.learning_rate
        }
        
        with open(f"{filepath}_config.pkl", 'wb') as f:
            pickle.dump(config, f)
        
        # Save training history if available
        if self.history is not None:
            with open(f"{filepath}_history.pkl", 'wb') as f:
                pickle.dump(self.history.history, f)
        
        print(f"✅ Model saved to {filepath}.keras")
    
    @classmethod
    def load_model(cls, filepath='lstm_typhoon_model'):
        """
        Load a saved model
        
        Args:
            filepath: Path to saved model (without extension)
        
        Returns:
            Loaded LSTM model instance
        """
        if not TENSORFLOW_AVAILABLE:
            raise ImportError("TensorFlow is required. Install with: pip install tensorflow")
        
        # Load configuration
        with open(f"{filepath}_config.pkl", 'rb') as f:
            config = pickle.load(f)
        
        # Create instance
        instance = cls(**config)
        
        # Load Keras model
        instance.model = keras.models.load_model(f"{filepath}.keras")
        
        # Load history if available
        history_file = f"{filepath}_history.pkl"
        if os.path.exists(history_file):
            with open(history_file, 'rb') as f:
                history_dict = pickle.load(f)
                # Recreate history object
                instance.history = type('History', (), {'history': history_dict})()
        
        print(f"✅ Model loaded from {filepath}.keras")
        return instance
    
    def plot_training_history(self, save_path='lstm_training_history.png'):
        """
        Plot training history
        
        Args:
            save_path: Path to save the plot
        """
        if self.history is None:
            print("No training history available")
            return
        
        try:
            import matplotlib.pyplot as plt
            
            history_dict = self.history.history
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
            
            # Loss plot
            ax1.plot(history_dict['loss'], label='Training Loss', linewidth=2)
            if 'val_loss' in history_dict:
                ax1.plot(history_dict['val_loss'], label='Validation Loss', linewidth=2)
            ax1.set_xlabel('Epoch', fontsize=12)
            ax1.set_ylabel('Loss (MSE)', fontsize=12)
            ax1.set_title('Training and Validation Loss', fontsize=14, fontweight='bold')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # MAE plot
            ax2.plot(history_dict['mae'], label='Training MAE', linewidth=2)
            if 'val_mae' in history_dict:
                ax2.plot(history_dict['val_mae'], label='Validation MAE', linewidth=2)
            ax2.set_xlabel('Epoch', fontsize=12)
            ax2.set_ylabel('MAE', fontsize=12)
            ax2.set_title('Training and Validation MAE', fontsize=14, fontweight='bold')
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"✅ Training history plot saved to {save_path}")
            plt.close()
            
        except ImportError:
            print("Matplotlib not available for plotting")
