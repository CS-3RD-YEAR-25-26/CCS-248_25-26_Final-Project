"""
Visualization Module for Typhoon Track Prediction System
Creates interactive maps showing historical tracks and predictions
"""

import folium
from folium import plugins
import numpy as np
from datetime import datetime
import webbrowser
import os


class TyphoonVisualizer:
    """
    Handles visualization of typhoon tracks and predictions
    """
    
    def __init__(self):
        """Initialize the visualizer"""
        self.map_object = None
    
    def calculate_distance(self, pos1, pos2):
        """
        Calculate distance between two positions in kilometers using Haversine formula
        
        Args:
            pos1: [lat, lon] of first position
            pos2: [lat, lon] of second position
            
        Returns:
            Distance in kilometers
        """
        lat1, lon1 = np.radians(pos1)
        lat2, lon2 = np.radians(pos2)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
        c = 2 * np.arcsin(np.sqrt(a))
        
        # Earth's radius in kilometers
        r = 6371
        
        return c * r
    
    def create_map(self, storm_track, predicted_position=None, actual_next_position=None,
                   storm_name="Typhoon", window_positions=None):
        """
        Create an interactive map with typhoon track and prediction
        
        Args:
            storm_track: DataFrame with storm track data
            predicted_position: [lat, lon] of predicted next position
            actual_next_position: [lat, lon] of actual next position (if available)
            storm_name: Name of the storm
            window_positions: Positions used for prediction (to highlight)
            
        Returns:
            Folium map object
        """
        # Extract coordinates
        lats = storm_track['LAT'].values
        lons = storm_track['LON'].values
        times = storm_track['ISO_TIME'].values
        
        # Calculate map center
        center_lat = np.mean(lats)
        center_lon = np.mean(lons)
        
        # Create map
        self.map_object = folium.Map(
            location=[center_lat, center_lon],
            zoom_start=6,
            tiles='OpenStreetMap'
        )
        
        # Add historical track as polyline
        historical_track = [[lat, lon] for lat, lon in zip(lats, lons)]
        
        folium.PolyLine(
            historical_track,
            color='blue',
            weight=3,
            opacity=0.7,
            popup=f'{storm_name} Historical Track'
        ).add_to(self.map_object)
        
        # Add markers for historical positions
        for i, (lat, lon, time) in enumerate(zip(lats, lons, times)):
            # Highlight window positions if provided
            if window_positions is not None and i >= len(lats) - len(window_positions):
                color = 'orange'
                icon = 'star'
                popup_text = f'Input Position {i + 1}<br>Time: {time}<br>Lat: {lat:.3f}<br>Lon: {lon:.3f}'
            else:
                color = 'blue'
                icon = 'circle'
                popup_text = f'Position {i + 1}<br>Time: {time}<br>Lat: {lat:.3f}<br>Lon: {lon:.3f}'
            
            folium.Marker(
                location=[lat, lon],
                popup=popup_text,
                icon=folium.Icon(color=color, icon=icon)
            ).add_to(self.map_object)
        
        # Add prediction marker if provided
        if predicted_position is not None:
            folium.Marker(
                location=[predicted_position[0], predicted_position[1]],
                popup=f'Predicted Next Position<br>Lat: {predicted_position[0]:.3f}<br>Lon: {predicted_position[1]:.3f}',
                icon=folium.Icon(color='red', icon='flag')
            ).add_to(self.map_object)
            
            # Draw line from last position to prediction
            folium.PolyLine(
                [[lats[-1], lons[-1]], [predicted_position[0], predicted_position[1]]],
                color='red',
                weight=3,
                opacity=0.7,
                dash_array='10',
                popup='Predicted Path'
            ).add_to(self.map_object)
        
        # Add actual next position if provided (for comparison)
        if actual_next_position is not None:
            folium.Marker(
                location=[actual_next_position[0], actual_next_position[1]],
                popup=f'Actual Next Position<br>Lat: {actual_next_position[0]:.3f}<br>Lon: {actual_next_position[1]:.3f}',
                icon=folium.Icon(color='green', icon='ok-sign')
            ).add_to(self.map_object)
            
            # Draw line from last position to actual
            folium.PolyLine(
                [[lats[-1], lons[-1]], [actual_next_position[0], actual_next_position[1]]],
                color='green',
                weight=3,
                opacity=0.7,
                dash_array='5',
                popup='Actual Path'
            ).add_to(self.map_object)
            
            # Calculate and display error
            if predicted_position is not None:
                error_km = self.calculate_distance(predicted_position, actual_next_position)
                
                # Add error circle around prediction
                folium.Circle(
                    location=[predicted_position[0], predicted_position[1]],
                    radius=error_km * 1000,  # Convert to meters
                    color='red',
                    fill=True,
                    fillOpacity=0.1,
                    popup=f'Prediction Error: {error_km:.2f} km'
                ).add_to(self.map_object)
        
        # Add legend
        legend_html = f'''
        <div style="position: fixed; 
                    top: 10px; right: 10px; width: 250px; height: auto; 
                    background-color: white; border:2px solid grey; z-index:9999; 
                    font-size:14px; padding: 10px">
        <p style="margin-top:0"><b>{storm_name}</b></p>
        <p><span style="color:blue">━━━</span> Historical Track</p>
        <p><span style="color:orange">⭐</span> Input Positions</p>
        '''
        
        if predicted_position is not None:
            legend_html += '<p><span style="color:red">🚩</span> Predicted Position</p>'
            legend_html += '<p><span style="color:red">┅┅┅</span> Predicted Path</p>'
        
        if actual_next_position is not None:
            legend_html += '<p><span style="color:green">✓</span> Actual Position</p>'
            legend_html += '<p><span style="color:green">┄┄┄</span> Actual Path</p>'
            
            if predicted_position is not None:
                error_km = self.calculate_distance(predicted_position, actual_next_position)
                legend_html += f'<p><b>Error: {error_km:.2f} km</b></p>'
        
        legend_html += '</div>'
        
        self.map_object.get_root().html.add_child(folium.Element(legend_html))
        
        # Add fullscreen option
        plugins.Fullscreen().add_to(self.map_object)
        
        return self.map_object
    
    def save_map(self, filename='typhoon_track_map.html'):
        """
        Save the map to an HTML file
        
        Args:
            filename: Name of the output HTML file
        """
        if self.map_object is None:
            print("No map to save. Create a map first.")
            return
        
        self.map_object.save(filename)
        print(f"Map saved to {filename}")
        
        return filename
    
    def display_map(self, filename='typhoon_track_map.html'):
        """
        Save and open the map in a web browser
        
        Args:
            filename: Name of the output HTML file
        """
        filepath = self.save_map(filename)
        
        # Get absolute path
        abs_path = os.path.abspath(filepath)
        
        # Open in web browser
        webbrowser.open('file://' + abs_path)
        
        print(f"Map opened in browser: {abs_path}")
    
    def plot_training_history(self, loss_history, save_path='training_history.png'):
        """
        Plot training loss history
        
        Args:
            loss_history: List of loss values per epoch
            save_path: Path to save the plot
        """
        try:
            import matplotlib.pyplot as plt
            
            plt.figure(figsize=(10, 6))
            plt.plot(loss_history, linewidth=2)
            plt.xlabel('Epoch', fontsize=12)
            plt.ylabel('Loss (MSE)', fontsize=12)
            plt.title('Training Loss History', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(save_path, dpi=150)
            print(f"Training history plot saved to {save_path}")
            plt.close()
            
        except ImportError:
            print("Matplotlib not available. Skipping training history plot.")
