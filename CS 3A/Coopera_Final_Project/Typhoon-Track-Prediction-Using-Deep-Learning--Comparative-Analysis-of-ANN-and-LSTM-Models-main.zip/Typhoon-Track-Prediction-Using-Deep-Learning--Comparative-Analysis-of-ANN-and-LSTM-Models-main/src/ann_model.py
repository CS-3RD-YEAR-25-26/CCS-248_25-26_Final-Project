"""
Artificial Neural Network Model for Typhoon Track Prediction
Implements a feedforward ANN with backpropagation for position forecasting
"""

import numpy as np
import pickle
import os


class ArtificialNeuralNetwork:
    """
    Feedforward Artificial Neural Network with backpropagation
    Designed for typhoon trajectory prediction
    """
    
    def __init__(self, input_size, hidden_sizes=[64, 32], output_size=2, learning_rate=0.001):
        """
        Initialize the ANN
        
        Args:
            input_size: Number of input features (window_size * 2)
            hidden_sizes: List of hidden layer sizes
            output_size: Number of output neurons (2 for lat, lon)
            learning_rate: Learning rate for gradient descent
        """
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.learning_rate = learning_rate
        
        # Initialize network architecture
        self.layers = []
        self.weights = []
        self.biases = []
        
        # Build layer sizes
        layer_sizes = [input_size] + hidden_sizes + [output_size]
        
        # Initialize weights and biases using He initialization
        for i in range(len(layer_sizes) - 1):
            # He initialization for better convergence
            weight = np.random.randn(layer_sizes[i], layer_sizes[i + 1]) * np.sqrt(2.0 / layer_sizes[i])
            bias = np.zeros((1, layer_sizes[i + 1]))
            
            self.weights.append(weight)
            self.biases.append(bias)
        
        self.num_layers = len(self.weights)
        
        # Training history
        self.loss_history = []
    
    def relu(self, x):
        """ReLU activation function"""
        return np.maximum(0, x)
    
    def relu_derivative(self, x):
        """Derivative of ReLU"""
        return (x > 0).astype(float)
    
    def linear(self, x):
        """Linear activation for output layer"""
        return x
    
    def forward_pass(self, X):
        """
        Forward propagation through the network
        
        Args:
            X: Input data
            
        Returns:
            Output prediction and layer activations
        """
        activations = [X]
        z_values = []
        
        # Forward through hidden layers
        for i in range(self.num_layers - 1):
            z = np.dot(activations[-1], self.weights[i]) + self.biases[i]
            z_values.append(z)
            a = self.relu(z)
            activations.append(a)
        
        # Output layer (linear activation)
        z = np.dot(activations[-1], self.weights[-1]) + self.biases[-1]
        z_values.append(z)
        output = self.linear(z)
        activations.append(output)
        
        return output, activations, z_values
    
    def backward_pass(self, X, y, activations, z_values):
        """
        Backward propagation to compute gradients
        
        Args:
            X: Input data
            y: True labels
            activations: Activations from forward pass
            z_values: Pre-activation values
            
        Returns:
            Gradients for weights and biases
        """
        m = X.shape[0]  # Number of samples
        
        # Initialize gradients
        dW = [np.zeros_like(w) for w in self.weights]
        db = [np.zeros_like(b) for b in self.biases]
        
        # Output layer gradient (MSE loss derivative)
        delta = activations[-1] - y
        
        # Backpropagate through layers
        for i in range(self.num_layers - 1, -1, -1):
            # Compute gradients
            dW[i] = np.dot(activations[i].T, delta) / m
            db[i] = np.sum(delta, axis=0, keepdims=True) / m
            
            # Propagate delta to previous layer
            if i > 0:
                delta = np.dot(delta, self.weights[i].T) * self.relu_derivative(z_values[i - 1])
        
        return dW, db
    
    def update_parameters(self, dW, db):
        """
        Update weights and biases using gradient descent
        
        Args:
            dW: Weight gradients
            db: Bias gradients
        """
        for i in range(self.num_layers):
            self.weights[i] -= self.learning_rate * dW[i]
            self.biases[i] -= self.learning_rate * db[i]
    
    def compute_loss(self, y_true, y_pred):
        """
        Compute Mean Squared Error loss
        
        Args:
            y_true: True values
            y_pred: Predicted values
            
        Returns:
            MSE loss
        """
        return np.mean((y_true - y_pred) ** 2)
    
    def train(self, X_train, y_train, epochs=1000, batch_size=32, verbose=True):
        """
        Train the neural network using mini-batch gradient descent
        
        Args:
            X_train: Training input data
            y_train: Training output data
            epochs: Number of training epochs
            batch_size: Batch size for mini-batch gradient descent
            verbose: Whether to print training progress
        """
        n_samples = X_train.shape[0]
        n_batches = max(1, n_samples // batch_size)
        
        print(f"Training ANN for {epochs} epochs...")
        print(f"Network architecture: {self.input_size} -> {' -> '.join(map(str, self.hidden_sizes))} -> {self.output_size}")
        
        for epoch in range(epochs):
            # Shuffle data
            indices = np.random.permutation(n_samples)
            X_shuffled = X_train[indices]
            y_shuffled = y_train[indices]
            
            epoch_loss = 0
            
            # Mini-batch training
            for batch in range(n_batches):
                start_idx = batch * batch_size
                end_idx = min((batch + 1) * batch_size, n_samples)
                
                X_batch = X_shuffled[start_idx:end_idx]
                y_batch = y_shuffled[start_idx:end_idx]
                
                # Forward pass
                y_pred, activations, z_values = self.forward_pass(X_batch)
                
                # Compute loss
                batch_loss = self.compute_loss(y_batch, y_pred)
                epoch_loss += batch_loss
                
                # Backward pass
                dW, db = self.backward_pass(X_batch, y_batch, activations, z_values)
                
                # Update parameters
                self.update_parameters(dW, db)
            
            # Average loss for epoch
            avg_loss = epoch_loss / n_batches
            self.loss_history.append(avg_loss)
            
            # Print progress
            if verbose and (epoch + 1) % 100 == 0:
                print(f"Epoch {epoch + 1}/{epochs} - Loss: {avg_loss:.6f}")
        
        print("Training completed!")
    
    def predict(self, X):
        """
        Make predictions using the trained network
        
        Args:
            X: Input data
            
        Returns:
            Predictions
        """
        output, _, _ = self.forward_pass(X)
        return output
    
    def save_model(self, filepath):
        """
        Save the model to a file
        
        Args:
            filepath: Path to save the model
        """
        model_data = {
            'input_size': self.input_size,
            'hidden_sizes': self.hidden_sizes,
            'output_size': self.output_size,
            'learning_rate': self.learning_rate,
            'weights': self.weights,
            'biases': self.biases,
            'loss_history': self.loss_history
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"Model saved to {filepath}")
    
    @classmethod
    def load_model(cls, filepath):
        """
        Load a model from a file
        
        Args:
            filepath: Path to the saved model
            
        Returns:
            Loaded ANN model
        """
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        # Create model instance
        model = cls(
            input_size=model_data['input_size'],
            hidden_sizes=model_data['hidden_sizes'],
            output_size=model_data['output_size'],
            learning_rate=model_data['learning_rate']
        )
        
        # Load weights and biases
        model.weights = model_data['weights']
        model.biases = model_data['biases']
        model.loss_history = model_data['loss_history']
        
        print(f"Model loaded from {filepath}")
        
        return model
    
    def evaluate(self, X_test, y_test):
        """
        Evaluate the model on test data
        
        Args:
            X_test: Test input data
            y_test: Test output data
            
        Returns:
            Test loss
        """
        y_pred = self.predict(X_test)
        test_loss = self.compute_loss(y_test, y_pred)
        
        return test_loss
