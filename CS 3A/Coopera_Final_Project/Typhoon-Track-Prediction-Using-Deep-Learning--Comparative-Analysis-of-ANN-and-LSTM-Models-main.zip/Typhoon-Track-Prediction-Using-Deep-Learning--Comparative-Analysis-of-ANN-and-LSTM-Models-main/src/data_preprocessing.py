"""
Data Preprocessing Module for Typhoon Track Prediction System
Handles loading, filtering, and preparing historical typhoon track data from IBTrACS dataset
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler


class TyphoonDataProcessor:
    """
    Processes typhoon track data for ANN training and prediction
    """
    
    def __init__(self, csv_file_path):
        """
        Initialize the data processor
        
        Args:
            csv_file_path: Path to IBTrACS CSV file
        """
        self.csv_file_path = csv_file_path
        self.data = None
        self.scaler_lat = MinMaxScaler()
        self.scaler_lon = MinMaxScaler()
        
    def load_data(self):
        """
        Load typhoon track data from CSV file
        
        Returns:
            DataFrame with typhoon track data
        """
        print("Loading typhoon track data...")
        # Load only essential columns to handle large file
        columns_to_load = ['SID', 'SEASON', 'NAME', 'ISO_TIME', 'LAT', 'LON', 'NATURE']
        
        try:
            self.data = pd.read_csv(
                self.csv_file_path,
                usecols=columns_to_load,
                na_values=[' ', '', 'NA', 'N/A'],
                low_memory=False
            )
            
            # Convert LAT and LON to numeric
            self.data['LAT'] = pd.to_numeric(self.data['LAT'], errors='coerce')
            self.data['LON'] = pd.to_numeric(self.data['LON'], errors='coerce')
            
            # Remove rows with missing coordinates
            self.data = self.data.dropna(subset=['LAT', 'LON'])
            
            # Convert ISO_TIME to datetime
            self.data['ISO_TIME'] = pd.to_datetime(self.data['ISO_TIME'], errors='coerce')
            
            # Sort by SID and time
            self.data = self.data.sort_values(['SID', 'ISO_TIME'])
            
            print(f"Loaded {len(self.data)} data points from {self.data['SID'].nunique()} storms")
            
            return self.data
            
        except Exception as e:
            print(f"Error loading data: {e}")
            raise
    
    def get_storm_list(self):
        """
        Get list of unique storms with their names and years
        
        Returns:
            DataFrame with storm information
        """
        if self.data is None:
            self.load_data()
        
        storms = self.data.groupby('SID').agg({
            'NAME': 'first',
            'SEASON': 'first',
            'LAT': 'count'
        }).reset_index()
        
        storms.columns = ['SID', 'NAME', 'SEASON', 'NUM_POINTS']
        storms = storms.sort_values('SEASON', ascending=False)
        
        return storms
    
    def get_storm_track(self, storm_id):
        """
        Get track data for a specific storm
        
        Args:
            storm_id: Storm identifier (SID)
            
        Returns:
            DataFrame with storm track data
        """
        if self.data is None:
            self.load_data()
        
        storm_track = self.data[self.data['SID'] == storm_id].copy()
        storm_track = storm_track.sort_values('ISO_TIME')
        
        return storm_track
    
    def create_sliding_window_sequences(self, storm_track, window_size=5):
        """
        Create input-output sequences using sliding window approach
        
        Args:
            storm_track: DataFrame with storm track data
            window_size: Number of previous time steps to use as input
            
        Returns:
            X: Input sequences (previous positions)
            y: Output values (next position)
        """
        # Extract latitude and longitude
        lat_values = storm_track['LAT'].values
        lon_values = storm_track['LON'].values
        
        if len(lat_values) <= window_size:
            print(f"Warning: Storm has only {len(lat_values)} points, need at least {window_size + 1}")
            return None, None
        
        # Create sequences
        X = []
        y = []
        
        for i in range(len(lat_values) - window_size):
            # Input: previous window_size positions
            lat_window = lat_values[i:i + window_size]
            lon_window = lon_values[i:i + window_size]
            
            # Combine lat and lon into feature vector
            features = []
            for j in range(window_size):
                features.extend([lat_window[j], lon_window[j]])
            
            X.append(features)
            
            # Output: next position
            y.append([lat_values[i + window_size], lon_values[i + window_size]])
        
        return np.array(X), np.array(y)
    
    def normalize_data(self, X, y, fit=True):
        """
        Normalize latitude and longitude values
        
        Args:
            X: Input sequences
            y: Output values
            fit: Whether to fit the scaler (True for training, False for prediction)
            
        Returns:
            X_normalized, y_normalized
        """
        # X has shape (samples, window_size * 2)
        # First half are latitudes, second half are longitudes
        X_norm = X.copy()
        y_norm = y.copy()
        
        window_size = X.shape[1] // 2
        
        if fit:
            # Fit scaler on all latitude and longitude values
            all_lats = np.concatenate([X[:, :window_size].flatten(), y[:, 0]])
            all_lons = np.concatenate([X[:, window_size:].flatten(), y[:, 1]])
            
            self.scaler_lat.fit(all_lats.reshape(-1, 1))
            self.scaler_lon.fit(all_lons.reshape(-1, 1))
        
        # Normalize latitudes (first half of features)
        for i in range(window_size):
            X_norm[:, i] = self.scaler_lat.transform(X[:, i].reshape(-1, 1)).flatten()
        
        # Normalize longitudes (second half of features)
        for i in range(window_size):
            X_norm[:, window_size + i] = self.scaler_lon.transform(X[:, window_size + i].reshape(-1, 1)).flatten()
        
        # Normalize output
        y_norm[:, 0] = self.scaler_lat.transform(y[:, 0].reshape(-1, 1)).flatten()
        y_norm[:, 1] = self.scaler_lon.transform(y[:, 1].reshape(-1, 1)).flatten()
        
        return X_norm, y_norm
    
    def denormalize_prediction(self, prediction):
        """
        Convert normalized prediction back to original scale
        
        Args:
            prediction: Normalized [lat, lon] prediction
            
        Returns:
            Denormalized [lat, lon] values
        """
        lat = self.scaler_lat.inverse_transform([[prediction[0]]])[0][0]
        lon = self.scaler_lon.inverse_transform([[prediction[1]]])[0][0]
        
        return np.array([lat, lon])
    
    def prepare_training_data(self, storm_ids, window_size=5):
        """
        Prepare training data from multiple storms
        
        Args:
            storm_ids: List of storm identifiers
            window_size: Number of previous time steps to use
            
        Returns:
            X_train, y_train: Normalized training data
        """
        all_X = []
        all_y = []
        
        for storm_id in storm_ids:
            storm_track = self.get_storm_track(storm_id)
            X, y = self.create_sliding_window_sequences(storm_track, window_size)
            
            if X is not None and len(X) > 0:
                all_X.append(X)
                all_y.append(y)
        
        if not all_X:
            raise ValueError("No valid sequences created from provided storms")
        
        X_combined = np.vstack(all_X)
        y_combined = np.vstack(all_y)
        
        # Normalize
        X_norm, y_norm = self.normalize_data(X_combined, y_combined, fit=True)
        
        return X_norm, y_norm
    
    def prepare_prediction_input(self, recent_positions, window_size=5):
        """
        Prepare input for prediction from recent positions
        
        Args:
            recent_positions: Array of recent [lat, lon] positions
            window_size: Number of previous time steps to use
            
        Returns:
            Normalized input array ready for prediction
        """
        if len(recent_positions) < window_size:
            raise ValueError(f"Need at least {window_size} recent positions")
        
        # Take the last window_size positions
        positions = recent_positions[-window_size:]
        
        # Flatten into feature vector
        features = []
        for pos in positions:
            features.extend([pos[0], pos[1]])  # lat, lon
        
        X = np.array([features])
        
        # Create dummy y for normalization (will not be used)
        y_dummy = np.array([[positions[-1][0], positions[-1][1]]])
        
        # Normalize without fitting
        X_norm, _ = self.normalize_data(X, y_dummy, fit=False)
        
        return X_norm
