# Typhoon Track Prediction Report - LaTeX Documentation

## Compilation Instructions

### Prerequisites

Install a LaTeX distribution:
- **Windows**: MiKTeX or TeX Live
- **macOS**: MacTeX
- **Linux**: TeX Live

### Required LaTeX Packages

The document uses the following packages (auto-installed by most distributions):
- inputenc, geometry, graphicx
- amsmath, amssymb
- booktabs, float, hyperref
- caption, subcaption
- algorithm, algpseudocode
- listings, xcolor
- multirow, array, siunitx

### Compilation Commands

#### Method 1: Using pdflatex (Recommended)
```bash
cd docs
pdflatex Typhoon_Track_Prediction_Report.tex
pdflatex Typhoon_Track_Prediction_Report.tex  # Run twice for references
```

#### Method 2: Using latexmk (Automatic)
```bash
cd docs
latexmk -pdf Typhoon_Track_Prediction_Report.tex
```

#### Method 3: Using Online Editor
1. Upload `Typhoon_Track_Prediction_Report.tex` to Overleaf (https://www.overleaf.com)
2. Click "Recompile" to generate PDF

### Output

The compilation will generate:
- `Typhoon_Track_Prediction_Report.pdf` - Final report
- `Typhoon_Track_Prediction_Report.aux` - Auxiliary file
- `Typhoon_Track_Prediction_Report.log` - Compilation log
- `Typhoon_Track_Prediction_Report.toc` - Table of contents

## Document Structure

The report contains the following sections:

1. **Title Page** - Project title, author, date
2. **Abstract** - Brief summary of the research
3. **Table of Contents** - Automatic navigation
4. **Introduction** - Background, objectives, scope
5. **Literature Review** - Related work and context
6. **Data and Methodology** - IBTrACS dataset and problem formulation
7. **Baseline ANN Model** - Architecture and initial results
8. **LSTM Model Development** - Improved model design
9. **Experimental Results** - Comprehensive performance comparison
10. **Discussion** - Key findings and analysis
11. **Conclusions and Future Work** - Summary and recommendations
12. **References** - Bibliography
13. **Appendices** - Implementation details and additional results

## Key Features

### Mathematical Equations
- LSTM cell operations
- Haversine distance formula
- Loss function definitions

### Tables
- Comprehensive performance metrics
- Hyperparameter configurations
- Accuracy comparisons
- Architecture specifications

### Code Listings
- Model architecture (Python)
- Training configuration
- Implementation snippets

### Professional Formatting
- IEEE-style citations
- Proper mathematical notation
- Structured sections
- Clear typography

## Customization

### Modify Title/Author
Edit lines 34-36:
```latex
\title{\textbf{Your Title Here}}
\author{Your Name\\Your Institution}
\date{Date}
```

### Add Figures
Place images in same directory and use:
```latex
\begin{figure}[H]
\centering
\includegraphics[width=0.8\textwidth]{filename.png}
\caption{Your caption}
\label{fig:label}
\end{figure}
```

### Update Results
Modify tables in Section 6 (Experimental Results) with your actual values.

## Tips for Best Results

1. **Run pdflatex twice** - Ensures cross-references work correctly
2. **Check warnings** - Review .log file for any issues
3. **Use vector graphics** - PDF/EPS images for better quality
4. **Proofread carefully** - Check equations and numbers

## Converting to Other Formats

### To Word (.docx)
```bash
pandoc Typhoon_Track_Prediction_Report.tex -o Report.docx
```

### To HTML
```bash
pandoc Typhoon_Track_Prediction_Report.tex -s -o Report.html
```

### To Markdown
```bash
pandoc Typhoon_Track_Prediction_Report.tex -o Report.md
```

## Troubleshooting

### Missing Packages
If you get "File not found" errors:
```bash
# MiKTeX (Windows)
mpm --install package-name

# TeX Live (Linux/Mac)
tlmgr install package-name
```

### Compilation Errors
- Check .log file for specific error messages
- Ensure all braces {} are balanced
- Verify table syntax is correct
- Make sure all \end{} commands match \begin{}

## Academic Usage

This report template is suitable for:
- Final year projects
- Research papers
- Technical reports
- Thesis chapters
- Conference submissions

## License

This LaTeX document is part of the Typhoon Track Prediction System educational project.
Feel free to adapt for your own academic work with proper attribution.

## Contact

For questions about the report or compilation issues, refer to:
- LaTeX documentation: https://www.latex-project.org/
- Overleaf tutorials: https://www.overleaf.com/learn
- TeX Stack Exchange: https://tex.stackexchange.com/
