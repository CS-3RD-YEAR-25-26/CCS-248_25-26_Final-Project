# Project Organization Guide

## Directory Structure

This project follows a modular, organized structure for better maintainability and scalability.

### Source Code (`src/`)
Contains all reusable Python modules:
- **ann_model.py**: Traditional feedforward ANN implementation
- **lstm_model.py**: Advanced LSTM/RNN model
- **data_preprocessing.py**: Base data loading and processing
- **data_preprocessing_lstm.py**: Enhanced preprocessing for LSTM
- **visualization.py**: Map generation and plotting utilities
- **train_lstm.py**: Standalone LSTM training script

### Scripts (`scripts/`)
Application entry points:
- **main.py**: CLI application for training and prediction
- **streamlit_app.py**: Web-based GUI interface
- **run_streamlit.bat**: Windows launcher for Streamlit

### Notebooks (`notebooks/`)
Interactive analysis and demonstrations:
- **model_evaluation.ipynb**: ANN baseline evaluation
- **lstm_vs_ann_comparison.ipynb**: Comprehensive model comparison
- *_backup.ipynb: Backup versions (not tracked in git)

### Models (`models/`)
Trained model artifacts organized by type:
- **ann/**: ANN model files (*.pkl)
- **lstm/**: LSTM model files (*.keras, *_config.pkl, *_processor.pkl)

### Results (`results/`)
Output files organized by category:
- **visualizations/**: Charts, plots, training curves (*.png)
- **predictions/**: Interactive prediction maps (*.html)
- **evaluations/**: Metrics, summaries, comparisons (*.csv, *.txt)

### Data (`data/`)
Raw datasets:
- **ibtracs.WP.list.v04r01.csv**: IBTrACS Western Pacific data

### Documentation (`docs/`)
Project documentation:
- **system_description.txt**: Original system requirements
- **LSTM_IMPLEMENTATION_SUMMARY.md**: LSTM implementation details
- **README_original.md**: Previous README (archived)

## Configuration

### Centralized Configuration (`config.py`)
All paths and hyperparameters in one place:
```python
from config import IBTRACS_CSV, ANN_MODELS_DIR, LSTM_CONFIG
```

Benefits:
- Easy parameter tuning
- Consistent paths across modules
- Environment-specific settings

### Package Structure (`src/__init__.py`)
Makes modules easily importable:
```python
from src.ann_model import ArtificialNeuralNetwork
from src.lstm_model import LSTMTyphoonModel
```

### Installable Package (`setup.py`)
Install as package for system-wide access:
```bash
pip install -e .
```

Then use anywhere:
```python
from typhoon_track_prediction import TyphoonDataProcessor
```

## Import Path Management

All scripts now use proper relative imports:

### In `scripts/main.py`:
```python
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.data_preprocessing import TyphoonDataProcessor
from config import IBTRACS_CSV
```

### In `notebooks/`:
```python
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.ann_model import ArtificialNeuralNetwork
```

## Version Control (.gitignore)

Organized to ignore:
- ✅ Python cache (`__pycache__/`, `*.pyc`)
- ✅ Virtual environments (`.venv/`, `venv/`)
- ✅ IDE files (`.vscode/`, `.idea/`)
- ✅ Temporary results (root-level `*.png`, `*.csv`)
- ✅ Large data files in data/ directory

But preserve:
- ✅ Organized results in `results/` subdirectories
- ✅ Saved models in `models/` subdirectories
- ✅ Directory structure via `.gitkeep` files

## File Organization Best Practices

### For Development:
1. **Source code** → `src/`
2. **Scripts** → `scripts/`
3. **Notebooks** → `notebooks/`
4. **Tests** → `tests/` (future)

### For Outputs:
1. **Models** → `models/ann/` or `models/lstm/`
2. **Visualizations** → `results/visualizations/`
3. **Predictions** → `results/predictions/`
4. **Evaluations** → `results/evaluations/`

### For Documentation:
1. **System docs** → `docs/`
2. **README** → Root directory
3. **Code docs** → Docstrings in source files
4. **Examples** → `notebooks/`

## Migration from Old Structure

Old structure (flat):
```
├── ann_model.py
├── lstm_model.py
├── main.py
├── model_evaluation.ipynb
├── typhoon_ann_model.pkl
├── ann_vs_lstm_comparison.png
└── ...
```

New structure (organized):
```
├── src/
│   ├── ann_model.py
│   └── lstm_model.py
├── scripts/
│   └── main.py
├── notebooks/
│   └── model_evaluation.ipynb
├── models/
│   └── ann/
│       └── typhoon_ann_model.pkl
├── results/
│   └── visualizations/
│       └── ann_vs_lstm_comparison.png
└── config.py
```

## Benefits of New Organization

1. **Clarity**: Purpose of each file is immediately clear
2. **Scalability**: Easy to add new models, scripts, or notebooks
3. **Maintainability**: Changes isolated to specific modules
4. **Collaboration**: Standard structure familiar to other developers
5. **Deployment**: Easier to package and distribute
6. **Version Control**: Better git history and cleaner diffs

## Usage Examples

### Run CLI Application:
```bash
cd scripts
python main.py
```

### Run Web Application:
```bash
cd scripts
streamlit run streamlit_app.py
```

### Import in Python:
```python
import sys
sys.path.append('path/to/Carl_ANN')

from src.ann_model import ArtificialNeuralNetwork
from config import ANN_CONFIG

model = ArtificialNeuralNetwork(**ANN_CONFIG)
```

### Run Training Script:
```bash
cd src
python train_lstm.py
```

## Future Enhancements

- [ ] Add `tests/` directory for unit tests
- [ ] Create `experiments/` for research runs
- [ ] Add `configs/` for multiple configuration files
- [ ] Implement logging system
- [ ] Add Docker containerization
- [ ] Create CI/CD pipeline
