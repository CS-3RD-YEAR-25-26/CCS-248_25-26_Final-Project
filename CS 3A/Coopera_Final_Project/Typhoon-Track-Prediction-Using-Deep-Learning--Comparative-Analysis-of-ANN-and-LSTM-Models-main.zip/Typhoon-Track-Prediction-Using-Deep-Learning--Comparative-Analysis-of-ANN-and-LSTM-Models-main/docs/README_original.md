# Typhoon Track Visualization and Prediction System

An Artificial Neural Network (ANN) based system for predicting typhoon trajectories using historical track data from the IBTrACS dataset.

## System Overview

This system implements a comprehensive typhoon track prediction framework that combines:
- **Data preprocessing** from IBTrACS historical typhoon data
- **ANN-based prediction** using feedforward neural networks with backpropagation
- **Geospatial visualization** with interactive maps
- **Quantitative evaluation** through distance-based error metrics

## Features

- ✅ Load and preprocess historical typhoon track data
- ✅ Sliding window approach for sequential data preparation
- ✅ Feedforward ANN with customizable architecture
- ✅ Backpropagation training with MSE loss optimization
- ✅ Interactive map visualization using Folium
- ✅ Prediction error calculation in kilometers
- ✅ Model persistence (save/load trained models)
- ✅ Training history visualization

## System Architecture

### Components

1. **data_preprocessing.py** - Data loading, normalization, and sequence preparation
2. **ann_model.py** - Feedforward ANN implementation with backpropagation
3. **visualization.py** - Interactive map generation and error visualization
4. **main.py** - Main application orchestrating the complete workflow

### ANN Model

- **Input Layer**: Historical latitude-longitude pairs (window_size × 2 features)
- **Hidden Layers**: Configurable layers with ReLU activation (default: 64, 32 neurons)
- **Output Layer**: 2 neurons (predicted latitude and longitude)
- **Training**: Mini-batch gradient descent with MSE loss function

## Installation

### Prerequisites

- Python 3.7 or higher
- pip package manager

### Setup

1. Clone or download this repository

2. Install required dependencies:
```bash
pip install -r requirements.txt
```

3. Ensure the IBTrACS dataset file is in the project directory:
   - File: `ibtracs.WP.list.v04r01.csv`
   - Available from: [IBTrACS Database](https://www.ncdc.noaa.gov/ibtracs/)

## Usage

### Running the System

#### Web-Based Interface (Recommended)

Launch the Streamlit web application:
```bash
streamlit run streamlit_app.py
```

Or use the provided batch file (Windows):
```bash
run_streamlit.bat
```

The web interface will open automatically in your browser at `http://localhost:8501`

#### Command-Line Interface

Alternatively, use the CLI version:
```bash
python main.py
```

### Web Interface Features

- **🔮 Prediction Page** - Interactive storm selection and prediction visualization
- **🎓 Training Page** - Configure and train models with real-time progress
- **ℹ️ About Page** - System information and documentation

### Main Menu Options (CLI)

1. **Train New Model** - Train an ANN model on selected historical storms
2. **Make Prediction** - Use a trained model to predict typhoon positions
3. **Train and Predict** - Complete workflow (training followed by prediction)
4. **Exit** - Close the application

### Training Mode

1. Select number of storms to use for training
2. Configure window size (number of previous positions)
3. Set training epochs
4. Model automatically saves to `typhoon_ann_model.pkl`
5. Training history plot saved to `training_history.png`

### Prediction Mode

1. Load a trained model (or use just-trained model)
2. Select a storm from the list
3. Choose how many positions to visualize
4. View prediction results and error metrics
5. Interactive map opens automatically in browser

## Output Files

- **typhoon_ann_model.pkl** - Trained ANN model
- **training_history.png** - Loss curve during training
- **typhoon_[STORM_ID]_prediction.html** - Interactive map visualization

## Map Visualization

The interactive map displays:
- 🔵 **Blue line**: Historical typhoon track
- ⭐ **Orange stars**: Input positions used for prediction
- 🚩 **Red flag**: Predicted next position
- ✓ **Green marker**: Actual next position (if available)
- 🔴 **Red circle**: Prediction error radius

## Technical Details

### Data Normalization

- Latitude and longitude values normalized to [0, 1] range using MinMaxScaler
- Improves training stability and convergence
- Predictions denormalized for interpretability

### Sliding Window Approach

- Uses previous T time steps as input features
- Default window size: 5 positions
- Captures temporal movement patterns

### Distance Calculation

- Haversine formula for great-circle distance
- Results in kilometers for error quantification

## Example Workflow

### Web Interface Workflow
```
1. Run: streamlit run streamlit_app.py
2. Navigate to Training page
3. Configure: 10 storms, window size 5, 1000 epochs
4. Click "Start Training"
5. View: Real-time training progress and loss curves
6. Navigate to Prediction page
7. Select: A typhoon storm from dropdown
8. Click "Make Prediction"
9. View: Interactive map with predictions and error metrics
```

### CLI Workflow
```python
1. Run: python main.py
2. Select: Option 3 (Train and Predict)
3. Configure: 10 storms, window size 5, 1000 epochs
4. Wait: Model training completes
5. Select: A storm for prediction
6. View: Interactive map with prediction and error metrics
```

## System Requirements

- **RAM**: Minimum 4 GB (8 GB recommended for large datasets)
- **Storage**: ~500 MB for dataset and output files
- **Browser**: Modern web browser for map visualization

## Performance Notes

- Training time varies with number of storms and epochs
- Typical training: ~2-5 minutes for 10 storms, 1000 epochs
- Prediction: Near-instantaneous (<1 second)

## Data Source

This system uses the International Best Track Archive for Climate Stewardship (IBTrACS) dataset:
- **Dataset**: Western Pacific (WP) basin typhoons
- **Format**: CSV with latitude, longitude, time, and metadata
- **Coverage**: Historical typhoon tracks from 1884 to present

## Limitations

- Predictions based on historical patterns only
- Does not incorporate meteorological features (pressure, wind speed, etc.)
- Accuracy depends on training data quality and quantity
- Linear extrapolation may not capture sudden directional changes

## Future Enhancements

- Integration of meteorological variables
- LSTM/GRU for better temporal modeling
- Ensemble predictions
- Real-time data integration
- Multi-step ahead predictions

## License

This project is for educational and research purposes.

## Authors

Developed as part of the ANN Final Project - Typhoon Track Prediction System

## References

- IBTrACS Database: https://www.ncdc.noaa.gov/ibtracs/
- Folium Documentation: https://python-visualization.github.io/folium/
- Neural Networks and Deep Learning: http://neuralnetworksanddeeplearning.com/

---

**Note**: Always verify predictions with official meteorological agencies. This system is for educational demonstration purposes.
