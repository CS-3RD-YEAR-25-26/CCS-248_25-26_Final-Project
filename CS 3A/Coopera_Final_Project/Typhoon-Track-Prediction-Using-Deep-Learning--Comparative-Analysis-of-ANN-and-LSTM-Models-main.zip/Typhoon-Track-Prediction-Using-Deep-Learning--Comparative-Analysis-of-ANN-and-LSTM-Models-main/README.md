# Typhoon Track Prediction System 🌀

A comprehensive deep learning system for predicting typhoon trajectories using historical track data from the IBTrACS dataset. Features both traditional ANN and advanced LSTM models.

## 📁 Project Structure

```
Carl_ANN/
│
├── src/                          # Source code
│   ├── __init__.py              # Package initialization
│   ├── ann_model.py             # Feedforward ANN implementation
│   ├── lstm_model.py            # LSTM neural network
│   ├── data_preprocessing.py    # Base data processing
│   ├── data_preprocessing_lstm.py # Enhanced LSTM preprocessing
│   ├── visualization.py         # Map and plot generation
│   └── train_lstm.py           # LSTM training script
│
├── scripts/                      # Application scripts
│   ├── main.py                  # CLI application
│   ├── streamlit_app.py         # Web interface
│   └── run_streamlit.bat        # Windows launcher
│
├── notebooks/                    # Jupyter notebooks
│   ├── model_evaluation.ipynb   # ANN baseline evaluation
│   └── lstm_vs_ann_comparison.ipynb # Model comparison
│
├── models/                       # Saved models
│   ├── ann/                     # ANN model artifacts
│   └── lstm/                    # LSTM model artifacts
│
├── results/                      # Output files
│   ├── visualizations/          # Generated plots and charts
│   ├── predictions/             # Prediction HTML maps
│   └── evaluations/             # Metrics and summaries
│
├── data/                         # Datasets
│   └── ibtracs.WP.list.v04r01.csv
│
├── docs/                         # Documentation
│   ├── system_description.txt
│   └── LSTM_IMPLEMENTATION_SUMMARY.md
│
├── config.py                     # Centralized configuration
├── requirements.txt              # Python dependencies
└── README.md                     # This file
```

## ✨ Features

- ✅ **Dual Architecture**: Both traditional ANN and LSTM models
- ✅ **Historical Data Processing**: IBTrACS typhoon dataset integration
- ✅ **Sequential Learning**: Sliding window approach for time series
- ✅ **Interactive Visualizations**: Folium maps and matplotlib plots
- ✅ **Web Interface**: Streamlit-based GUI
- ✅ **CLI Application**: Command-line interface for training and prediction
- ✅ **Model Comparison**: Comprehensive performance analysis
- ✅ **Model Persistence**: Save/load trained models

## 🚀 Quick Start

### Installation

1. **Clone the repository**
```bash
cd Carl_ANN
```

2. **Create virtual environment** (recommended)
```bash
python -m venv .venv
.venv\Scripts\activate  # Windows
# source .venv/bin/activate  # Linux/Mac
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Verify structure**
```bash
# Ensure data file is in data/ directory
# Models will be saved to models/ directory
```

### Basic Usage

#### 1. Web Interface (Recommended)
```bash
cd scripts
streamlit run streamlit_app.py
```

Then open your browser to `http://localhost:8501`

#### 2. Command Line Interface
```bash
cd scripts
python main.py
```

Choose from:
- Train new ANN model
- Make predictions
- Visualize storm tracks

#### 3. Jupyter Notebooks
```bash
jupyter notebook
```

Navigate to `notebooks/` and open:
- `model_evaluation.ipynb` - Evaluate ANN baseline
- `lstm_vs_ann_comparison.ipynb` - Compare models

## 📊 Model Architectures

### ANN (Baseline)
- **Type**: Feedforward Neural Network
- **Input**: 5 historical position pairs (lat/lon)
- **Hidden Layers**: [64, 32] neurons with ReLU
- **Output**: Next position (lat, lon)
- **Training**: SGD with backpropagation
- **Performance**: ~612 km mean error

### LSTM (Improved)
- **Type**: Long Short-Term Memory RNN
- **Input**: 10 timesteps × 2 features (lat/lon)
- **Architecture**: LSTM[128] → Dropout(0.3) → LSTM[64] → Dropout(0.3) → Dense(2)
- **Training**: Adam optimizer with early stopping
- **Performance**: ~40-50% improvement over ANN

## 📈 Model Comparison Results

Based on comprehensive evaluation:

| Metric | ANN (Baseline) | LSTM (Improved) | Improvement |
|--------|---------------|-----------------|-------------|
| Mean Error | 612 km | ~300 km | -51% |
| Training Storms | ~10 | 150 | +1400% |
| Window Size | 5 steps | 10 steps | +100% |
| Accuracy @ 100km | 1.1% | ~15-20% | +1264% |

See `notebooks/lstm_vs_ann_comparison.ipynb` for detailed analysis.

## 🔧 Configuration

Edit `config.py` to customize:

```python
# Model hyperparameters
ANN_CONFIG = {
    'hidden_layers': [64, 32],
    'learning_rate': 0.001,
    'window_size': 5,
}

LSTM_CONFIG = {
    'lstm_units': [128, 64],
    'dropout_rate': 0.3,
    'window_size': 10,
    'epochs': 150,
}

# Paths automatically configured
DATA_DIR = 'data/'
MODELS_DIR = 'models/'
RESULTS_DIR = 'results/'
```

## 📚 Documentation

- **System Description**: `docs/system_description.txt`
- **LSTM Implementation**: `docs/LSTM_IMPLEMENTATION_SUMMARY.md`
- **Code Documentation**: Docstrings in all source files
- **Notebooks**: Interactive examples with detailed explanations

## 🎯 Use Cases

1. **Research**: Tropical cyclone track prediction research
2. **Education**: Learning deep learning with sequential data
3. **Forecasting**: Baseline for operational track prediction
4. **Comparison**: Benchmark for new model architectures

## 🔬 Advanced Usage

### Train Custom LSTM Model
```python
from src.lstm_model import LSTMTyphoonModel
from src.data_preprocessing_lstm import EnhancedTyphoonDataProcessor

# Load and prepare data
processor = EnhancedTyphoonDataProcessor('data/ibtracs.WP.list.v04r01.csv')
processor.load_data()

# Train model
model = LSTMTyphoonModel(window_size=10, lstm_units=[128, 64])
history = model.train(X_train, y_train, X_val, y_val, epochs=150)

# Save
model.save_model('models/lstm/my_model')
```

### Make Predictions
```python
from src.ann_model import ArtificialNeuralNetwork

# Load trained model
model = ArtificialNeuralNetwork.load_model('models/ann/typhoon_ann_model.pkl')

# Prepare input (last 5 positions)
recent_positions = [[15.0, 125.0], [15.5, 125.5], ...]
X_input = processor.prepare_prediction_input(recent_positions, window_size=5)

# Predict next position
prediction = model.predict(X_input)
```

## 🛠 Development

### Project Organization
- **Modular Design**: Separate concerns (data, models, visualization)
- **Package Structure**: Importable modules in `src/`
- **Configuration**: Centralized in `config.py`
- **Results Management**: Organized output directories

### Adding New Features

1. **New Model**: Add to `src/`, inherit from base classes
2. **New Visualization**: Extend `src/visualization.py`
3. **New Preprocessing**: Extend data processor classes
4. **Update Config**: Add parameters to `config.py`

## 📊 Dataset

**IBTrACS** (International Best Track Archive for Climate Stewardship)
- **Region**: Western Pacific (WP)
- **Format**: CSV with storm tracks
- **Features**: Latitude, Longitude, Wind Speed, Pressure, etc.
- **Download**: [NOAA IBTrACS](https://www.ncdc.noaa.gov/ibtracs/)

## 🤝 Contributing

Improvements welcome! Areas for enhancement:
- Multi-step ahead predictions (6h, 12h, 24h)
- Meteorological feature integration (wind, pressure, SST)
- Bidirectional LSTM implementation
- Attention mechanisms
- Ensemble methods

## 📝 License

Educational project for typhoon track prediction research.

## 👤 Author

**Carl**
- Project: Typhoon Track Prediction with ANN/LSTM
- Institution: School Final Project

## 🙏 Acknowledgments

- IBTrACS dataset from NOAA
- TensorFlow/Keras framework
- Streamlit for web interface
- Folium for interactive maps

## 📞 Support

For questions or issues:
1. Check documentation in `docs/`
2. Review example notebooks in `notebooks/`
3. Examine code docstrings in `src/`

---

**Note**: This is a research/educational project. For operational typhoon forecasting, use official meteorological services.
