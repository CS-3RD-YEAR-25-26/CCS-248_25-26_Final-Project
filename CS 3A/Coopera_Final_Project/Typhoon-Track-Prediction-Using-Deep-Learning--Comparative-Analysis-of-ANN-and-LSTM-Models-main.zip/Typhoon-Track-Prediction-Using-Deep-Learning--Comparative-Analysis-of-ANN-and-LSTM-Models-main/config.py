"""
Configuration file for the Typhoon Track Prediction System
"""
import os

# Project paths
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, 'data')
MODELS_DIR = os.path.join(PROJECT_ROOT, 'models')
RESULTS_DIR = os.path.join(PROJECT_ROOT, 'results')
DOCS_DIR = os.path.join(PROJECT_ROOT, 'docs')

# Data paths
IBTRACS_CSV = os.path.join(DATA_DIR, 'ibtracs.WP.list.v04r01.csv')

# Model paths
ANN_MODELS_DIR = os.path.join(MODELS_DIR, 'ann')
LSTM_MODELS_DIR = os.path.join(MODELS_DIR, 'lstm')

# Results paths
VISUALIZATIONS_DIR = os.path.join(RESULTS_DIR, 'visualizations')
PREDICTIONS_DIR = os.path.join(RESULTS_DIR, 'predictions')
EVALUATIONS_DIR = os.path.join(RESULTS_DIR, 'evaluations')

# ANN Model Configuration
ANN_CONFIG = {
    'hidden_layers': [64, 32],
    'learning_rate': 0.001,
    'window_size': 5,
    'activation': 'relu',
    'loss_function': 'mse',
}

# LSTM Model Configuration
LSTM_CONFIG = {
    'lstm_units': [128, 64],
    'dropout_rate': 0.3,
    'learning_rate': 0.001,
    'window_size': 10,
    'batch_size': 32,
    'epochs': 150,
}

# Training Configuration
TRAINING_CONFIG = {
    'val_split': 0.15,
    'test_split': 0.15,
    'num_training_storms': 150,
}

# Visualization Configuration
VIZ_CONFIG = {
    'map_zoom_start': 5,
    'map_center': [15.0, 125.0],  # Western Pacific
    'colormap': 'YlOrRd',
}
