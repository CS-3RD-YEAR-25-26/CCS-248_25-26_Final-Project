"""
Setup configuration for Typhoon Track Prediction System
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="typhoon-track-prediction",
    version="1.0.0",
    author="Carl",
    description="Deep learning system for typhoon track prediction using ANN and LSTM",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/typhoon-track-prediction",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    include_package_data=True,
    package_data={
        "": ["*.txt", "*.md", "*.csv"],
    },
    entry_points={
        "console_scripts": [
            "typhoon-train=scripts.main:main",
            "typhoon-web=streamlit run scripts.streamlit_app:main",
        ],
    },
)
